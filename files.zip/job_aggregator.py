"""
Job aggregator — searches multiple job boards in parallel.
Each source is a separate scraper class. Results are deduplicated.
"""
import asyncio
import hashlib
import logging
from typing import Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class RemoteOKScraper:
    """Scrapes Remote OK API (has a free public API)."""
    BASE_URL = "https://remoteok.com/api"

    async def search(self, keywords: list[str]) -> list[dict]:
        import aiohttp
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    self.BASE_URL,
                    headers={"User-Agent": "JobHunter/1.0"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    data = await resp.json()
                    jobs = []
                    for item in data[1:]:  # first item is metadata
                        if not isinstance(item, dict):
                            continue
                        title = item.get("position", "").lower()
                        if keywords and not any(k.lower() in title for k in keywords):
                            continue
                        jobs.append({
                            "external_id": item.get("id", ""),
                            "source": "remoteok",
                            "title": item.get("position", ""),
                            "company": item.get("company", ""),
                            "description": item.get("description", ""),
                            "skills_required": item.get("tags", []),
                            "apply_url": item.get("url", ""),
                            "salary_min": item.get("salary_min"),
                            "salary_max": item.get("salary_max"),
                            "is_remote": True,
                            "posted_at": item.get("date"),
                            "company_logo_url": item.get("company_logo"),
                        })
                    return jobs[:50]
        except Exception as e:
            logger.error(f"RemoteOK scraper error: {e}")
            return []


class WeWorkRemotelyScraper:
    """Scrapes We Work Remotely via RSS feed."""
    RSS_URL = "https://weworkremotely.com/remote-jobs.rss"

    async def search(self, keywords: list[str]) -> list[dict]:
        import aiohttp
        import xml.etree.ElementTree as ET
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.RSS_URL, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    text = await resp.text()
                    root = ET.fromstring(text)
                    jobs = []
                    for item in root.iter("item"):
                        title = item.findtext("title", "").lower()
                        if keywords and not any(k.lower() in title for k in keywords):
                            continue
                        raw_title = item.findtext("title", "")
                        parts = raw_title.split(": ", 1)
                        company = parts[0] if len(parts) > 1 else ""
                        job_title = parts[1] if len(parts) > 1 else raw_title
                        jobs.append({
                            "external_id": item.findtext("guid", ""),
                            "source": "weworkremotely",
                            "title": job_title,
                            "company": company,
                            "description": item.findtext("description", ""),
                            "apply_url": item.findtext("link", ""),
                            "is_remote": True,
                            "posted_at": item.findtext("pubDate"),
                        })
                    return jobs[:50]
        except Exception as e:
            logger.error(f"WeWorkRemotely scraper error: {e}")
            return []


class JobAggregator:
    """Aggregates jobs from multiple sources, deduplicates, returns unified list."""

    def __init__(self):
        self.scrapers = [
            RemoteOKScraper(),
            WeWorkRemotelyScraper(),
            # Add more scrapers here: LinkedIn, Glassdoor (via Playwright), etc.
        ]

    def _deduplicate(self, jobs: list[dict]) -> list[dict]:
        seen = set()
        unique = []
        for job in jobs:
            key = hashlib.md5(
                f"{job.get('title','').lower()}{job.get('company','').lower()}".encode()
            ).hexdigest()
            if key not in seen:
                seen.add(key)
                unique.append(job)
        return unique

    async def search(
        self,
        keywords: list[str],
        remote_only: bool = True,
        job_type: Optional[str] = None,
        salary_min: Optional[int] = None,
    ) -> list[dict]:
        tasks = [scraper.search(keywords) for scraper in self.scrapers]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_jobs = []
        for result in results:
            if isinstance(result, list):
                all_jobs.extend(result)

        deduped = self._deduplicate(all_jobs)

        # Apply filters
        if salary_min:
            deduped = [j for j in deduped if j.get("salary_min") and j["salary_min"] >= salary_min]

        logger.info(f"[JobAggregator] Found {len(deduped)} unique jobs")
        return deduped


job_aggregator = JobAggregator()
