# JobHunter AI — Full Architecture & Implementation Guide

## Project Structure

```
jobhunter-ai/
├── docker-compose.yml          # Full stack orchestration
├── README.md
│
├── backend/                    # Python FastAPI
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── .env.example
│   └── app/
│       ├── main.py             # FastAPI app + lifespan
│       ├── core/
│       │   ├── config.py       # Pydantic settings
│       │   ├── database.py     # Async SQLAlchemy + session
│       │   └── logging.py      # Structured logging
│       ├── models/             # SQLAlchemy ORM models
│       │   ├── user.py
│       │   ├── job.py
│       │   ├── resume.py
│       │   ├── application.py
│       │   └── cover_letter.py
│       ├── schemas/            # Pydantic request/response models
│       │   ├── user.py
│       │   ├── job.py
│       │   ├── resume.py
│       │   └── application.py
│       ├── api/v1/
│       │   ├── router.py
│       │   └── endpoints/
│       │       ├── auth.py
│       │       ├── users.py
│       │       ├── resumes.py
│       │       ├── jobs.py
│       │       ├── applications.py
│       │       └── agents.py
│       ├── services/           # Core business logic
│       │   ├── resume_parser.py      # PDF/DOCX → structured data
│       │   ├── resume_tailoring.py   # Claude-powered ATS optimization
│       │   ├── cover_letter.py       # Claude cover letter generation
│       │   ├── job_matching.py       # Embedding-based job scoring
│       │   └── file_generator.py    # PDF/DOCX output
│       ├── agents/             # LangGraph multi-agent system
│       │   └── orchestrator.py      # Full pipeline graph
│       ├── scrapers/
│       │   ├── job_aggregator.py    # Multi-source job search
│       │   └── auto_applier.py      # Playwright form automation
│       └── workers/
│           ├── celery_app.py        # Celery configuration
│           └── tasks.py             # Background job tasks
│
└── frontend/                   # Next.js 14 App Router
    ├── Dockerfile
    ├── package.json
    ├── tailwind.config.ts
    └── src/
        ├── app/
        │   ├── layout.tsx
        │   ├── page.tsx              # → redirect to /dashboard
        │   ├── dashboard/page.tsx    # Main dashboard
        │   ├── jobs/page.tsx         # Job feed + search
        │   ├── applications/page.tsx # Kanban + list view
        │   ├── resume/page.tsx       # Resume manager
        │   └── settings/page.tsx
        ├── components/
        │   ├── dashboard/            # Dashboard widgets
        │   ├── jobs/                 # Job cards, filters
        │   ├── resume/               # Upload, editor
        │   └── ui/                   # Base components
        ├── lib/
        │   └── api.ts               # Typed axios API client
        ├── store/
        │   └── useAppStore.ts       # Zustand global state
        └── hooks/                   # Custom React hooks
```

---

## Database Schema

```sql
-- Users
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  hashed_password VARCHAR(255),
  full_name VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  oauth_provider VARCHAR(50),
  oauth_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Jobs (cached from scrapers)
CREATE TABLE jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id VARCHAR(255),
  source VARCHAR(100),          -- remoteok, linkedin, etc.
  title VARCHAR(500) NOT NULL,
  company VARCHAR(255) NOT NULL,
  description TEXT,
  skills_required JSONB,
  is_remote BOOLEAN DEFAULT true,
  job_type VARCHAR(50),
  seniority VARCHAR(50),
  salary_min INTEGER,
  salary_max INTEGER,
  apply_url TEXT,
  ats_keywords JSONB,
  posted_at TIMESTAMP,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Resumes
CREATE TABLE resumes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  filename VARCHAR(500),
  file_path TEXT,
  file_type VARCHAR(20),
  status VARCHAR(50) DEFAULT 'uploaded',  -- uploaded|parsing|parsed|error
  raw_text TEXT,
  parsed_data JSONB,             -- full structured career data
  skills JSONB,
  experience_years INTEGER,
  career_level VARCHAR(50),
  ats_score FLOAT,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Resume variants (tailored per job)
CREATE TABLE resume_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resume_id UUID REFERENCES resumes(id) ON DELETE CASCADE,
  job_id UUID REFERENCES jobs(id),
  tailored_content JSONB,
  ats_score FLOAT,
  keyword_match_score FLOAT,
  pdf_path TEXT,
  docx_path TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Cover letters
CREATE TABLE cover_letters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  job_id UUID REFERENCES jobs(id),
  content TEXT NOT NULL,
  tone VARCHAR(50) DEFAULT 'professional',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Applications
CREATE TABLE applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  job_id UUID REFERENCES jobs(id),
  resume_variant_id UUID REFERENCES resume_variants(id),
  cover_letter_id UUID REFERENCES cover_letters(id),
  status VARCHAR(50) DEFAULT 'queued',   -- queued|applying|applied|viewed|interview|offer|rejected|failed
  mode VARCHAR(20) DEFAULT 'auto',       -- auto|semi_auto|manual
  match_score FLOAT,
  applied_at TIMESTAMP,
  notes TEXT,
  recruiter_email VARCHAR(255),
  interview_date TIMESTAMP,
  error_log TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

---

## AI Pipeline Flow

```
1. User uploads resume (PDF/DOCX)
   └── resume_parser_service.parse()
       └── Claude extracts: name, skills, experience, education → JSON

2. Agent.start() triggered
   └── job_aggregator.search(user_preferences)
       ├── RemoteOK API
       ├── WeWorkRemotely RSS
       └── [LinkedIn, Glassdoor via Playwright — add here]

3. For each job:
   └── resume_tailoring_service.tailor_resume()
       └── Claude: ATS keyword matching, reorder skills, tailor summary
   └── cover_letter_service.generate()
       └── Claude: personalized letter in chosen tone

4. auto_applier.apply() [if auto-apply enabled]
   └── Playwright: navigate → fill form → upload files → detect CAPTCHA
   └── On CAPTCHA: flag for human review

5. Application stored in DB, status tracked
   └── Analytics updated: match scores, response rates
```

---

## Environment Variables

```bash
# Required
ANTHROPIC_API_KEY=sk-ant-...        # Primary AI model
DATABASE_URL=postgresql+asyncpg://...
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key

# Optional
OPENAI_API_KEY=sk-...               # Fallback AI model
ENVIRONMENT=development|production
MAX_UPLOAD_SIZE_MB=10
SCRAPER_CONCURRENCY=5
USE_ROTATING_PROXIES=false
```

---

## Next Steps to Complete

### Phase 1 (MVP) — Missing pieces:
- [ ] `app/core/logging.py` — structured logging with structlog
- [ ] `app/schemas/` — Pydantic v2 request/response schemas for all endpoints
- [ ] `app/services/job_matching.py` — ChromaDB embedding-based match scoring
- [ ] `app/services/file_generator.py` — WeasyPrint PDF + python-docx DOCX output
- [ ] `app/workers/celery_app.py` — Celery + Redis task queue setup
- [ ] Alembic migrations — `alembic init`, write initial migration
- [ ] Auth implementation — JWT tokens, password hashing in `endpoints/auth.py`
- [ ] Frontend pages: `/jobs`, `/applications`, `/resume`, `/settings`

### Phase 2 — AI features:
- [ ] Resume scoring dashboard component
- [ ] Cover letter tone selector UI
- [ ] ATS keyword gap analysis display
- [ ] Job match score explainability

### Phase 3 — Automation:
- [ ] LinkedIn scraper via Playwright (rate limiting, cookie auth)
- [ ] Greenhouse/Lever ATS form detection and auto-fill
- [ ] CAPTCHA webhook → notify user for manual completion
- [ ] Email integration for recruiter reply detection

### Phase 4 — Scale:
- [ ] Vector embeddings for semantic job matching
- [ ] Learning loop: track what tailoring choices led to interviews
- [ ] Admin panel with user monitoring and scraper health

