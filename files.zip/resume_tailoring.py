"""
AI Resume Tailoring Service
Uses Claude to tailor resumes for specific job postings.
"""
import json
import re
from typing import Optional
import anthropic
from app.core.config import settings


TAILORING_SYSTEM_PROMPT = """You are an expert resume optimizer and career coach.
Your job is to tailor a candidate's resume to match a specific job description.

Rules:
- NEVER invent or fabricate experience, skills, or qualifications
- Only reorder, rephrase, and emphasize existing experience
- Maximize ATS keyword match with the job description
- Keep the tone professional and appropriate for the industry
- Preserve all factual accuracy

Return a JSON object with this exact structure:
{
  "summary": "tailored professional summary",
  "skills_highlighted": ["skill1", "skill2"],
  "experience": [{"title": "", "company": "", "dates": "", "bullets": [""]}],
  "ats_score": 0-100,
  "keyword_match_score": 0-100,
  "keywords_added": ["keyword1"],
  "keywords_missing": ["keyword2"],
  "improvement_notes": "brief explanation of changes made"
}"""


class ResumeTailoringService:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def tailor_resume(
        self,
        resume_data: dict,
        job_description: str,
        job_title: str,
        company: str,
    ) -> dict:
        """
        Tailor a resume for a specific job posting.
        Returns structured JSON with the optimized content.
        """
        prompt = f"""
Job Title: {job_title}
Company: {company}

Job Description:
{job_description}

Candidate's Current Resume Data:
{json.dumps(resume_data, indent=2)}

Please tailor this resume for the job above. Maximize keyword alignment
and ATS compatibility while preserving truthfulness.
"""
        message = self.client.messages.create(
            model=settings.DEFAULT_AI_MODEL,
            max_tokens=4096,
            system=TAILORING_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )

        raw = message.content[0].text
        # Strip any markdown code fences if present
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        return json.loads(clean)

    async def extract_ats_keywords(self, job_description: str) -> list[str]:
        """Extract ATS-relevant keywords from a job description."""
        message = self.client.messages.create(
            model=settings.DEFAULT_AI_MODEL,
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": f"""Extract the top 20 ATS keywords from this job description.
Return ONLY a JSON array of strings, nothing else.

Job description:
{job_description}"""
            }],
        )
        raw = message.content[0].text
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        return json.loads(clean)

    async def score_resume(self, resume_text: str, job_description: str) -> dict:
        """Score how well a resume matches a job description."""
        message = self.client.messages.create(
            model=settings.DEFAULT_AI_MODEL,
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": f"""Score this resume against the job description.
Return ONLY a JSON object: {{"ats_score": 0-100, "match_score": 0-100, "missing_keywords": [], "present_keywords": []}}

Resume:
{resume_text}

Job Description:
{job_description}"""
            }],
        )
        raw = message.content[0].text
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        return json.loads(clean)


resume_tailoring_service = ResumeTailoringService()
