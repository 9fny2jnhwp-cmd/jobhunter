"""
Multi-agent orchestration using LangGraph.
Defines the agent pipeline: Search → Score → Tailor → Apply → Track
"""
from typing import TypedDict, Annotated, Sequence
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
import operator
import logging

logger = logging.getLogger(__name__)


class AgentState(TypedDict):
    user_id: str
    resume_data: dict
    job_preferences: dict
    # Jobs discovered
    raw_jobs: Annotated[list, operator.add]
    scored_jobs: list
    # Per-job processing
    current_job: dict | None
    tailored_resume: dict | None
    cover_letter: str | None
    # Tracking
    applications_submitted: Annotated[list, operator.add]
    errors: Annotated[list, operator.add]
    # Control flow
    should_apply: bool
    run_complete: bool


async def job_search_node(state: AgentState) -> dict:
    """Searches multiple job boards for matching positions."""
    from app.scrapers.job_aggregator import job_aggregator
    logger.info(f"[JobSearchAgent] Searching for user {state['user_id']}")
    jobs = await job_aggregator.search(
        keywords=state["job_preferences"].get("keywords", []),
        remote_only=state["job_preferences"].get("remote_only", True),
        job_type=state["job_preferences"].get("job_type"),
        salary_min=state["job_preferences"].get("salary_min"),
    )
    return {"raw_jobs": jobs}


async def scoring_node(state: AgentState) -> dict:
    """Scores and ranks jobs against the candidate profile."""
    from app.services.job_matching import job_matching_service
    scored = await job_matching_service.score_jobs(
        jobs=state["raw_jobs"],
        resume_data=state["resume_data"],
        preferences=state["job_preferences"],
    )
    # Filter out low scores and sort descending
    qualified = [j for j in scored if j["match_score"] >= 60]
    qualified.sort(key=lambda x: x["match_score"], reverse=True)
    logger.info(f"[ScoringAgent] {len(qualified)}/{len(scored)} jobs qualified")
    return {"scored_jobs": qualified}


async def resume_tailoring_node(state: AgentState) -> dict:
    """Tailors resume for the current job."""
    from app.services.resume_tailoring import resume_tailoring_service
    job = state["current_job"]
    if not job:
        return {"tailored_resume": None}
    tailored = await resume_tailoring_service.tailor_resume(
        resume_data=state["resume_data"],
        job_description=job["description"],
        job_title=job["title"],
        company=job["company"],
    )
    return {"tailored_resume": tailored}


async def cover_letter_node(state: AgentState) -> dict:
    """Generates cover letter for the current job."""
    from app.services.cover_letter import cover_letter_service
    job = state["current_job"]
    tone = state["job_preferences"].get("cover_letter_tone", "professional")
    letter = await cover_letter_service.generate(
        resume_data=state["resume_data"],
        job_title=job["title"],
        company=job["company"],
        job_description=job["description"],
        tone=tone,
    )
    return {"cover_letter": letter}


async def auto_apply_node(state: AgentState) -> dict:
    """Submits the application using browser automation."""
    from app.scrapers.auto_applier import auto_applier
    job = state["current_job"]
    result = await auto_applier.apply(
        job=job,
        resume_data=state["tailored_resume"],
        cover_letter=state["cover_letter"],
    )
    if result["success"]:
        return {"applications_submitted": [{"job_id": job["id"], "status": "applied"}]}
    else:
        return {"errors": [{"job_id": job["id"], "error": result["error"]}]}


def should_apply_router(state: AgentState) -> str:
    """Decides whether to auto-apply or skip to tracking."""
    if state.get("should_apply") and state.get("current_job"):
        return "apply"
    return "track"


def build_agent_graph() -> StateGraph:
    """Builds the LangGraph agent pipeline."""
    workflow = StateGraph(AgentState)

    workflow.add_node("search", job_search_node)
    workflow.add_node("score", scoring_node)
    workflow.add_node("tailor_resume", resume_tailoring_node)
    workflow.add_node("cover_letter", cover_letter_node)
    workflow.add_node("apply", auto_apply_node)

    workflow.set_entry_point("search")
    workflow.add_edge("search", "score")
    workflow.add_edge("score", "tailor_resume")
    workflow.add_edge("tailor_resume", "cover_letter")
    workflow.add_conditional_edges("cover_letter", should_apply_router, {
        "apply": "apply",
        "track": END,
    })
    workflow.add_edge("apply", END)

    return workflow.compile(checkpointer=MemorySaver())


agent_graph = build_agent_graph()
