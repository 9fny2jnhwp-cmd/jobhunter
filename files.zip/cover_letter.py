"""
AI Cover Letter Generation Service
"""
import anthropic
from app.core.config import settings

TONE_INSTRUCTIONS = {
    "professional": "formal, polished, traditional corporate tone",
    "corporate": "highly formal, structured, conservative",
    "startup": "enthusiastic, culture-forward, conversational yet professional",
    "creative": "engaging, personality-driven, memorable",
    "technical": "precise, skills-focused, concise",
}

class CoverLetterService:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def generate(
        self,
        resume_data: dict,
        job_title: str,
        company: str,
        job_description: str,
        tone: str = "professional",
    ) -> str:
        tone_desc = TONE_INSTRUCTIONS.get(tone, TONE_INSTRUCTIONS["professional"])

        prompt = f"""Write a cover letter for this candidate applying for the following role.

Role: {job_title} at {company}
Tone: {tone_desc}

Job Description:
{job_description}

Candidate Profile:
Name: {resume_data.get('full_name', 'the candidate')}
Summary: {resume_data.get('summary', '')}
Key Skills: {', '.join(resume_data.get('skills', [])[:10])}
Most Recent Role: {resume_data.get('most_recent_title', '')} at {resume_data.get('most_recent_company', '')}

Requirements:
- 3-4 paragraphs, under 400 words
- Reference specific aspects of the job description
- Highlight the 2-3 most relevant experiences
- Sound human and genuine, not templated
- Do NOT start with "I am writing to..."
- End with a clear call to action
- Return just the letter body, no subject line or headers"""

        message = self.client.messages.create(
            model=settings.DEFAULT_AI_MODEL,
            max_tokens=2048,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text


cover_letter_service = CoverLetterService()
