# JobHunter AI — Autonomous Remote Job Application Platform

A production-grade AI-powered platform that autonomously searches remote jobs, tailors resumes, generates cover letters, and auto-applies — built on Next.js + FastAPI.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React, TailwindCSS, shadcn/ui, Framer Motion |
| Backend | Python FastAPI, Uvicorn, Pydantic |
| AI | Claude API (primary), OpenAI (fallback), LangGraph agents |
| Database | PostgreSQL via Supabase, Prisma ORM |
| Queue | Redis + Celery (background jobs) |
| Scraping | Playwright, Scrapy, rotating proxies |
| Auth | Supabase Auth + NextAuth |
| File Gen | WeasyPrint (PDF), python-docx (DOCX) |
| Vector DB | ChromaDB (local) / Pinecone (production) |
| Deploy | Docker Compose, Vercel (frontend), Railway (backend) |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Next.js Frontend                      │
│  Dashboard │ Job Feed │ Resume Builder │ Analytics       │
└──────────────────────┬──────────────────────────────────┘
                       │ REST + WebSocket
┌──────────────────────▼──────────────────────────────────┐
│                  FastAPI Backend                          │
│  Auth │ Jobs │ Resume │ Applications │ AI │ Files        │
└───┬──────────────┬────────────────┬───────────────────┬─┘
    │              │                │                   │
┌───▼───┐   ┌──────▼──────┐  ┌────▼────┐  ┌──────────▼──┐
│Supabase│   │Redis+Celery │  │ChromaDB │  │  AI Agents  │
│  DB   │   │  Job Queue  │  │Vectors  │  │  LangGraph  │
└───────┘   └─────────────┘  └─────────┘  └─────────────┘
```

---

## Agent Architecture (LangGraph)

```
JobSearchAgent  →  ResumeOptAgent  →  CoverLetterAgent
      ↓                  ↓                   ↓
  ScoringAgent  →  AutoApplyAgent   →  TrackingAgent
      ↓                  ↓                   ↓
FeedbackAgent   ←  AnalyticsAgent  ←  NotifyAgent
```

---

## Quickstart

```bash
git clone https://github.com/your-org/jobhunter-ai
cd jobhunter-ai

# Copy env files
cp .env.example .env
cp frontend/.env.local.example frontend/.env.local

# Start everything
docker-compose up --build

# Frontend: http://localhost:3000
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/docs
```

---

## Phase Roadmap

| Phase | Features | Status |
|-------|----------|--------|
| 1 | Auth, Resume Upload, Parsing, Dashboard | 🔨 Building |
| 2 | Resume Tailoring, Cover Letter Gen, AI Matching | 📋 Planned |
| 3 | Auto-Apply Engine, Browser Automation | 📋 Planned |
| 4 | Multi-Agent Orchestration, Analytics, Learning | 📋 Planned |

