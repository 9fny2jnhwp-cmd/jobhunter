"""
Resume parsing service — extracts structured data from uploaded resumes.
Supports PDF, DOCX, TXT.
"""
import json
import re
from pathlib import Path
import anthropic

# Optional heavy imports — gracefully degrade if not installed
try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False

try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

from app.core.config import settings

PARSE_SYSTEM_PROMPT = """You are a resume parser. Extract all information from the resume text and return structured JSON.

Return ONLY valid JSON with this schema:
{
  "full_name": "",
  "email": "",
  "phone": "",
  "location": "",
  "linkedin_url": "",
  "github_url": "",
  "portfolio_url": "",
  "summary": "",
  "skills": [],
  "experience": [{"title": "", "company": "", "dates": "", "location": "", "bullets": []}],
  "education": [{"degree": "", "institution": "", "dates": "", "gpa": ""}],
  "certifications": [],
  "languages": [],
  "most_recent_title": "",
  "most_recent_company": "",
  "experience_years": 0,
  "career_level": "junior|mid|senior|lead|director|executive",
  "industries": [],
  "job_titles_history": [],
  "salary_expectation": null
}"""


class ResumeParserService:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

    def extract_text(self, file_path: str, file_type: str) -> str:
        """Extract raw text from resume file."""
        path = Path(file_path)

        if file_type == "pdf" and HAS_PDFPLUMBER:
            with pdfplumber.open(path) as pdf:
                return "\n".join(
                    page.extract_text() or "" for page in pdf.pages
                )
        elif file_type == "docx" and HAS_DOCX:
            doc = Document(path)
            return "\n".join(para.text for para in doc.paragraphs)
        elif file_type == "txt":
            return path.read_text(encoding="utf-8", errors="ignore")
        else:
            # Fallback: read as text
            return path.read_text(encoding="utf-8", errors="ignore")

    async def parse(self, file_path: str, file_type: str) -> dict:
        """Parse resume and return structured data using Claude."""
        raw_text = self.extract_text(file_path, file_type)

        message = self.client.messages.create(
            model=settings.DEFAULT_AI_MODEL,
            max_tokens=4096,
            system=PARSE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": f"Parse this resume:\n\n{raw_text}"}],
        )

        raw = message.content[0].text
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        parsed = json.loads(clean)
        parsed["raw_text"] = raw_text
        return parsed


resume_parser_service = ResumeParserService()
