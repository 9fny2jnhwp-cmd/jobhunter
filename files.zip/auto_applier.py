"""
Auto-application engine using Playwright for browser automation.
Handles form filling, file uploads, multi-step forms, and CAPTCHA detection.
"""
import logging
from typing import Optional

logger = logging.getLogger(__name__)

CAPTCHA_INDICATORS = [
    "captcha", "recaptcha", "hcaptcha", "cloudflare", "are you human",
    "robot", "verify you", "turnstile",
]

STANDARD_QUESTIONS = {
    "authorized to work": "Yes",
    "require sponsorship": "No",
    "legally authorized": "Yes",
    "18 years": "Yes",
    "willing to relocate": "No",
    "years of experience": "5",
}


class AutoApplier:
    """
    Autonomous job application bot.
    Uses Playwright to navigate and fill application forms.
    """

    async def apply(self, job: dict, resume_data: dict, cover_letter: str) -> dict:
        """
        Attempt to auto-apply to a job.
        Returns {"success": bool, "error": str | None}
        """
        try:
            from playwright.async_api import async_playwright

            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                               "AppleWebKit/537.36 (KHTML, like Gecko) "
                               "Chrome/120.0.0.0 Safari/537.36"
                )
                page = await context.new_page()

                apply_url = job.get("apply_url", "")
                if not apply_url:
                    return {"success": False, "error": "No apply URL"}

                await page.goto(apply_url, timeout=30000)
                await page.wait_for_load_state("networkidle")

                # Check for CAPTCHA
                content = await page.content()
                if self._detect_captcha(content):
                    logger.warning(f"CAPTCHA detected for {job['title']} at {job['company']}")
                    await browser.close()
                    return {"success": False, "error": "captcha_detected", "needs_human": True}

                # Detect form type and fill accordingly
                filled = await self._fill_form(page, resume_data, cover_letter)

                if filled:
                    # Don't actually submit in development/test mode
                    # await page.click('button[type="submit"]')
                    logger.info(f"[AutoApplier] Ready to submit: {job['title']} at {job['company']}")
                    await browser.close()
                    return {"success": True, "error": None}
                else:
                    await browser.close()
                    return {"success": False, "error": "form_fill_failed"}

        except Exception as e:
            logger.error(f"[AutoApplier] Error: {e}")
            return {"success": False, "error": str(e)}

    def _detect_captcha(self, html: str) -> bool:
        html_lower = html.lower()
        return any(indicator in html_lower for indicator in CAPTCHA_INDICATORS)

    async def _fill_form(self, page, resume_data: dict, cover_letter: str) -> bool:
        """Fill common application form fields."""
        try:
            # Name fields
            for selector in ['input[name*="name"][name*="first"]', 'input[placeholder*="First"]']:
                el = page.locator(selector).first
                if await el.count() > 0:
                    await el.fill(resume_data.get("full_name", "").split()[0])

            for selector in ['input[name*="name"][name*="last"]', 'input[placeholder*="Last"]']:
                el = page.locator(selector).first
                if await el.count() > 0:
                    await el.fill(resume_data.get("full_name", "").split()[-1])

            # Email
            for selector in ['input[type="email"]', 'input[name*="email"]']:
                el = page.locator(selector).first
                if await el.count() > 0:
                    await el.fill(resume_data.get("email", ""))

            # Phone
            for selector in ['input[type="tel"]', 'input[name*="phone"]']:
                el = page.locator(selector).first
                if await el.count() > 0:
                    await el.fill(resume_data.get("phone", ""))

            # Cover letter textarea
            for selector in ['textarea[name*="cover"]', 'textarea[placeholder*="cover"]', 'textarea[name*="message"]']:
                el = page.locator(selector).first
                if await el.count() > 0:
                    await el.fill(cover_letter)
                    break

            # Answer standard yes/no questions
            for question_keyword, answer in STANDARD_QUESTIONS.items():
                labels = page.locator(f'label:has-text("{question_keyword}")')
                count = await labels.count()
                if count > 0:
                    radio = page.locator(f'input[type="radio"][value="{answer}"]').first
                    if await radio.count() > 0:
                        await radio.check()

            return True
        except Exception as e:
            logger.error(f"Form fill error: {e}")
            return False


auto_applier = AutoApplier()
